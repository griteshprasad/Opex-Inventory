<?php
$con =mysqli_connect("localhost","root","","opex");
 if (mysqli_connect_error())
 {
	 echo "failed to connect to MYSQLI". mysqli_connect_error();
}

?>