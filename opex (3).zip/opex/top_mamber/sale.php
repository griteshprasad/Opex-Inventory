
           <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
		
		        <section class="content-header">
          <h1>
            
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Sale</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
		  <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Sales Charts</h3>
                  <div class="box-tools">
				 
                    <div class="input-group">
					 
				  
                      <input type="text" name="table_search" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                      <div class="input-group-btn">
                        <button class="btn btn-sm btn-default"><i class="fa fa-search"></i></button>
                      </div>
					  
                    </div>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table class="table table-hover">
                    <tr>
                      <th>ID</th>
                      <th>Sales Order</th>
                      <th>Order Date (Units)</th>
                      <th>Customer Name</th>
                      <th>Invoice</th>
					  <th>Status</th>
					  <th>Production</th>
					   <th>Packed</th>
                      <th>Shipped</th>
					  <th>Delivered</th>
                      <th>Amount</th>
					  <th><i class="fa fa-pencil-square-o">Edit</i></th>
                    </tr>
                    <tr>
                      <td>13</td>
					  <td>90 </td>
					  <td>15/11/2018</td>
                      <td>John Doe</td>
                      <td>1171034</td>
                      <td><span class="label label-success">Approved</span><br>15/11/2018</td>
					  <td><span class="label label-success">complete</span><br>18/11/2018</td>
					  <td><span class="label label-success">complete</span><br>19/11/2018</td>
					  <td><span class="label label-success">complete</span><br>20/11/2018</td>
					   <td><span class="label label-warning">Pending</span><br>22/11/2018</td>
					   <td>4500000/-</td>
					   <td><i class="fa fa-pencil-square-o"></i></td>
                    </tr>
                    <tr>
                      <td>13</td>
					  <td>100 </td>
					  <td>16/11/2018</td>
                      <td>John Doe</td>
                      <td>1171034</td>
                      <td><span class="label label-success">Approved</span><br>16/11/2018</td>
					  <td><span class="label label-warning">Pending</span><br>19/11/2018</td>
					  <td><span class="label label-warning">Pending</span><br>20/11/2018</td>
					  <td><span class="label label-warning">Pending</span><br>21/11/2018</td>
					   <td><span class="label label-warning">Pending</span><br>23/11/2018</td>
					   <td>5000000/-</td>
					   <td><i class="fa fa-pencil-square-o"></i></td>
                    </tr>
                    <tr>
                      <td>13</td>
					  <td>90 </td>
					  <td>17/11/2018</td>
                      <td>John Doe</td>
                      <td>1171034</td>
                      <td><span class="label label-warning">Pending</span><br>18/11/2018</td>
					  <td><span class="label label-warning">Pending</span><br>19/11/2018</td>
					  <td><span class="label label-warning">Pending</span><br>20/11/2018</td>
					  <td><span class="label label-warning">Pending</span><br>21/11/2018</td>
					   <td><span class="label label-warning">Pending</span><br>24/11/2018</td>
					    <td>4500000/-</td>
						<td><i class="fa fa-pencil-square-o"></i></td>
						
						
						
						
						
						
						
						
						
                    </tr>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
          </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
     