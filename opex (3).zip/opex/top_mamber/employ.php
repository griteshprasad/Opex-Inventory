
           <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
		
		        <section class="content-header">
          <h1>
            
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> employ</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
		  <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Employee Charts</h3>
                  <div class="box-tools">
				 
                    <div class="input-group">
					 
				  
                      <input type="text" name="table_search" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                      <div class="input-group-btn">
                        <button class="btn btn-sm btn-default"><i class="fa fa-search"></i></button>
                      </div>
					  
                    </div>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table class="table table-hover">
                    <tr>
                      <th>ID</th>
                      <th>Employee Name</th>
                      <th>Adhar No.</th>
                      <th>Employee Contact No.</th>
                      <th>Img</th>
					  <th>Pan No.</th>
					  <th>Today's Attendence</th>
					   <th>Email Id</th>
                      <th>Account Details</th>
					  <th><i class="fa fa-pencil-square-o">Edit</i></th>
                    </tr>
                    <tr>
                      <td>1</td>
					  <td>John Doe</td>
					  <td>115037895845</td>
                      <td>+919041352836</td>
                      <td> <img src="img/profile.png" width="50" height="50" class="img-circle" alt="User Image" />  </td>
                      <td>1154Ed55</td>
					  <td><span class="label label-success">   Present </span></td>
					  <td>saad@gmail.com</td>
					  <td>a/c no:- 11550046523526
					  Ifse:-sbi8752545</td>
					   <td><i class="fa fa-pencil-square-o"></i></td>
                    </tr>
                    <tr>
                      <td>2</td>
					  <td>John Doe</td>
					  <td>115037895845</td>
                      <td>+919041352836</td>
                      <td> <img src="img/profile.png" width="50" height="50" class="img-circle" alt="User Image" />  </td>
                      <td>1154Ed55</td>
					  <td><span class="label label-success">   Present  </span></td>
					  <td>saad@gmail.com</td>
					  <td>a/c no:- 11550046523526
					  Ifse:-sbi8752545</td>
					   <td><i class="fa fa-pencil-square-o"></i></td>
                    </tr>
                    <tr>
                      <td>3</td>
					  <td>John Doe</td>
					  <td>115037895845</td>
                      <td>+919041352836</td>
                      <td><img src="img/profile.png" width="50" height="50" class="img-circle" alt="User Image" />   </td>
                      <td>1154Ed55</td>
					  <td><span class="label label-success">   Present  </span></td>
					  <td>saad@gmail.com</td>
					  <td>a/c no:- 11550046523526
					  Ifse:-sbi8752545</td>
					   <td><i class="fa fa-pencil-square-o"></i></td>
                    </tr>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
          </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
     